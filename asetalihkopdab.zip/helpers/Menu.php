<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => ''
		),
		
		array(
			'path' => 'ibu_pejabat', 
			'label' => 'Ibu Pejabat', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'ibu_pejabat', 
			'label' => 'Ibu Pejabat', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_hq', 
			'label' => 'Borang HQ', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'pts_parit_raja', 
			'label' => 'Pts Parit Raja', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'pts_parit_raja', 
			'label' => 'Pts Parit Raja', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_parit_raja', 
			'label' => 'Borang Parit Raja', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'pts_semerah', 
			'label' => 'Pts Semerah', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'pts_semerah', 
			'label' => 'Pts Semerah', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_semerah', 
			'label' => 'Borang Semerah', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'pts_sri_dayong', 
			'label' => 'Pts Sri Dayong', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'pts_sri_dayong', 
			'label' => 'Pts Sri Dayong', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_sri_dayong', 
			'label' => 'Borang Sri Dayong', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'pts_parit_yaani', 
			'label' => 'Pts Parit Yaani', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'pts_parit_yaani', 
			'label' => 'Pts Parit Yaani', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_parit_yaani', 
			'label' => 'Borang Parit Yaani', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'rengit', 
			'label' => 'Rengit', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'rengit', 
			'label' => 'Rengit', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_rengit', 
			'label' => 'Borang Rengit', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'warijo', 
			'label' => 'Warijo', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'warijo', 
			'label' => 'Warijo', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_warijo', 
			'label' => 'Borang Warijo', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'bilik_kursus', 
			'label' => 'Bilik Kursus', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'bilik_kursus', 
			'label' => 'Bilik Kursus', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_bilik_kursus', 
			'label' => 'Borang Bilik Kursus', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'tapak_semaian', 
			'label' => 'Tapak Semaian', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'tapak_semaian', 
			'label' => 'Tapak Semaian', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_tapak_semaian', 
			'label' => 'Borang Tapak Semai', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'kedai_input', 
			'label' => 'Kedai Input', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'kedai_input', 
			'label' => 'Kedai Input', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_kedai_input', 
			'label' => 'Borang Kedai Input', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'parit_mahang', 
			'label' => 'Parit Mahang', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'parit_mahang', 
			'label' => 'Parit Mahang', 
			'icon' => ''
		),
		
		array(
			'path' => 'borang_parit_mahang', 
			'label' => 'Borang Parit Mahang', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'lokasi_pindahan_semasa', 
			'label' => 'Lokasi', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'lokasi_pindahan_semasa', 
			'label' => 'Lokasi Pindahan Semasa', 
			'icon' => ''
		),
		
		array(
			'path' => 'ruang_simpanan_hq', 
			'label' => 'Ruang Simpanan', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'kategori_aset_hq', 
			'label' => 'Kod Aset', 
			'icon' => '','submenu' => array(
		array(
			'path' => 'kategori_aset_hq', 
			'label' => 'Kategori Aset ', 
			'icon' => ''
		),
		
		array(
			'path' => 'kod_kategori_hq', 
			'label' => 'Kod Kategori', 
			'icon' => ''
		),
		
		array(
			'path' => 'kod_sub_kategori', 
			'label' => 'Kod Sub Kategori', 
			'icon' => ''
		),
		
		array(
			'path' => 'jenama_hq', 
			'label' => 'Jenama', 
			'icon' => ''
		)
	)
		),
		
		array(
			'path' => 'borang_aset_lupus', 
			'label' => 'Borang Aset Lupus', 
			'icon' => ''
		)
	);
		
	
	
			public static $kod_tempat = array(
		array(
			"value" => "23", 
			"label" => "23", 
		),);
		
			public static $kod_tempat2 = array(
		array(
			"value" => "51", 
			"label" => "51", 
		),);
		
			public static $username = array(
		array(
			"value" => "ibupejabat", 
			"label" => "ibupejabat", 
		),
		array(
			"value" => "parityaani", 
			"label" => "parityaani", 
		),
		array(
			"value" => "paritraja", 
			"label" => "paritraja", 
		),
		array(
			"value" => "semerah", 
			"label" => "semerah", 
		),
		array(
			"value" => "sridayong", 
			"label" => "sridayong", 
		),
		array(
			"value" => "tapaksemaian", 
			"label" => "tapaksemaian", 
		),
		array(
			"value" => "kedaiinput", 
			"label" => "kedaiinput", 
		),
		array(
			"value" => "paritmahang", 
			"label" => "paritmahang", 
		),
		array(
			"value" => "rengit", 
			"label" => "rengit", 
		),
		array(
			"value" => "warijo", 
			"label" => "warijo", 
		),
		array(
			"value" => "bilikkursus", 
			"label" => "bilikkursus", 
		),);
		
}