<?php 

/**
 * SharedController Controller
 * @category  Controller / Model
 */
class SharedController extends BaseController{
	
	/**
     * ibu_pejabat_ruang_simpanan_option_list Model Action
     * @return array
     */
	function ibu_pejabat_ruang_simpanan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod_tengah AS value,kod_tengah AS label FROM ruang_simpanan_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_kategori_aset_option_list Model Action
     * @return array
     */
	function ibu_pejabat_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_kod_kategori_option_list Model Action
     * @return array
     */
	function ibu_pejabat_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function ibu_pejabat_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_jenama_option_list Model Action
     * @return array
     */
	function ibu_pejabat_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function ibu_pejabat_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_status_inventori_option_list Model Action
     * @return array
     */
	function ibu_pejabat_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * ibu_pejabat_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function ibu_pejabat_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_kategori_aset_option_list Model Action
     * @return array
     */
	function bilik_kursus_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_kod_kategori_option_list Model Action
     * @return array
     */
	function bilik_kursus_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function bilik_kursus_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_jenama_option_list Model Action
     * @return array
     */
	function bilik_kursus_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function bilik_kursus_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_status_inventori_option_list Model Action
     * @return array
     */
	function bilik_kursus_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * bilik_kursus_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function bilik_kursus_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_kategori_aset_option_list Model Action
     * @return array
     */
	function kedai_input_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_kod_kategori_option_list Model Action
     * @return array
     */
	function kedai_input_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function kedai_input_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_jenama_option_list Model Action
     * @return array
     */
	function kedai_input_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function kedai_input_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_status_inventori_option_list Model Action
     * @return array
     */
	function kedai_input_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * kedai_input_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function kedai_input_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_kategori_aset_option_list Model Action
     * @return array
     */
	function parit_mahang_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_kod_kategori_option_list Model Action
     * @return array
     */
	function parit_mahang_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function parit_mahang_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_jenama_option_list Model Action
     * @return array
     */
	function parit_mahang_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function parit_mahang_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_kod_tempat_option_list Model Action
     * @return array
     */
	function parit_mahang_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_parit_mahang";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_status_inventori_option_list Model Action
     * @return array
     */
	function parit_mahang_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * parit_mahang_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function parit_mahang_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_kategori_aset_option_list Model Action
     * @return array
     */
	function pts_parit_raja_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_kod_kategori_option_list Model Action
     * @return array
     */
	function pts_parit_raja_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function pts_parit_raja_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_jenama_option_list Model Action
     * @return array
     */
	function pts_parit_raja_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function pts_parit_raja_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_raja_status_inventori_option_list Model Action
     * @return array
     */
	function pts_parit_raja_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_kategori_aset_option_list Model Action
     * @return array
     */
	function pts_semerah_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_kod_kategori_option_list Model Action
     * @return array
     */
	function pts_semerah_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function pts_semerah_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_jenama_option_list Model Action
     * @return array
     */
	function pts_semerah_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function pts_semerah_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_kod_tempat_option_list Model Action
     * @return array
     */
	function pts_semerah_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_semerah";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_semerah_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function pts_semerah_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_kategori_aset_option_list Model Action
     * @return array
     */
	function rengit_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_kod_kategori_option_list Model Action
     * @return array
     */
	function rengit_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function rengit_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_jenama_option_list Model Action
     * @return array
     */
	function rengit_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function rengit_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_kod_tempat_option_list Model Action
     * @return array
     */
	function rengit_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_rengit";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_status_inventori_option_list Model Action
     * @return array
     */
	function rengit_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * rengit_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function rengit_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_kategori_aset_option_list Model Action
     * @return array
     */
	function tapak_semaian_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_kod_kategori_option_list Model Action
     * @return array
     */
	function tapak_semaian_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function tapak_semaian_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_jenama_option_list Model Action
     * @return array
     */
	function tapak_semaian_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function tapak_semaian_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_kod_tempat_option_list Model Action
     * @return array
     */
	function tapak_semaian_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_tapak_semaian";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_status_inventori_option_list Model Action
     * @return array
     */
	function tapak_semaian_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * tapak_semaian_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function tapak_semaian_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_kategori_aset_option_list Model Action
     * @return array
     */
	function warijo_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_kod_kategori_option_list Model Action
     * @return array
     */
	function warijo_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function warijo_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_jenama_option_list Model Action
     * @return array
     */
	function warijo_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function warijo_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_kod_tempat_option_list Model Action
     * @return array
     */
	function warijo_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_warijo";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_status_inventori_option_list Model Action
     * @return array
     */
	function warijo_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * warijo_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function warijo_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_kategori_aset_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_kod_kategori_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_jenama_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_kod_tempat_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_parit_yaani";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_status_inventori_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_parit_yaani_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function pts_parit_yaani_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_kategori_aset_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_kategori_aset_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kategori_aset AS value,kategori_aset AS label FROM kategori_aset_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_kod_kategori_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_kod_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT nama_aset AS value,nama_aset AS label FROM kod_kategori_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_kod_sub_kategori_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_kod_sub_kategori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenis_aset AS value,jenis_aset AS label FROM kod_sub_kategori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_jenama_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_jenama_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT jenama AS value,jenama AS label FROM jenama_hq";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_lokasi_pindahan_semasa_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_lokasi_pindahan_semasa_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT cawangan AS value,cawangan AS label FROM lokasi_pindahan_semasa";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_kod_tempat_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_kod_tempat_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT kod AS value,kod AS label FROM kod_tempat_sri_dayong";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_status_inventori_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_status_inventori_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT status AS value,status AS label FROM status_inventori";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * pts_sri_dayong_maklumat_pelupusan_option_list Model Action
     * @return array
     */
	function pts_sri_dayong_maklumat_pelupusan_option_list(){
		$db = $this->GetModel();
		$sqltext = "SELECT  DISTINCT file AS value,file AS label FROM rujuk_file_aset_dan_lupus";
		$queryparams = null;
		$arr = $db->rawQuery($sqltext, $queryparams);
		return $arr;
	}

	/**
     * user_username_value_exist Model Action
     * @return array
     */
	function user_username_value_exist($val){
		$db = $this->GetModel();
		$db->where("username", $val);
		$exist = $db->has("user");
		return $exist;
	}

	/**
     * getcount_ibupejabat Model Action
     * @return Value
     */
	function getcount_ibupejabat(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM ibu_pejabat";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_bilikkursus Model Action
     * @return Value
     */
	function getcount_bilikkursus(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM bilik_kursus";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_kedaiinput Model Action
     * @return Value
     */
	function getcount_kedaiinput(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM kedai_input";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_paritmahang Model Action
     * @return Value
     */
	function getcount_paritmahang(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM parit_mahang";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_ptsparitraja Model Action
     * @return Value
     */
	function getcount_ptsparitraja(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM pts_parit_raja";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_ptssemerah Model Action
     * @return Value
     */
	function getcount_ptssemerah(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM pts_semerah";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_rengit Model Action
     * @return Value
     */
	function getcount_rengit(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM rengit";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_tapaksemaian Model Action
     * @return Value
     */
	function getcount_tapaksemaian(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM tapak_semaian";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_warijo Model Action
     * @return Value
     */
	function getcount_warijo(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM warijo";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_ptsparityaani Model Action
     * @return Value
     */
	function getcount_ptsparityaani(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM pts_parit_yaani";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_ptssridayong Model Action
     * @return Value
     */
	function getcount_ptssridayong(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM pts_sri_dayong";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_boranghq Model Action
     * @return Value
     */
	function getcount_boranghq(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_hq";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangparitmahang Model Action
     * @return Value
     */
	function getcount_borangparitmahang(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_parit_mahang";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangparitraja Model Action
     * @return Value
     */
	function getcount_borangparitraja(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_parit_raja";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangparityaani Model Action
     * @return Value
     */
	function getcount_borangparityaani(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_parit_yaani";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangrengit Model Action
     * @return Value
     */
	function getcount_borangrengit(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_rengit";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangsemerah Model Action
     * @return Value
     */
	function getcount_borangsemerah(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_semerah";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangsridayong Model Action
     * @return Value
     */
	function getcount_borangsridayong(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_sri_dayong";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangtapaksemaian Model Action
     * @return Value
     */
	function getcount_borangtapaksemaian(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_tapak_semaian";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangwarijo Model Action
     * @return Value
     */
	function getcount_borangwarijo(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_warijo";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangkedaiinput Model Action
     * @return Value
     */
	function getcount_borangkedaiinput(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_kedai_input";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangbilikkursus Model Action
     * @return Value
     */
	function getcount_borangbilikkursus(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_bilik_kursus";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

	/**
     * getcount_borangasetlupus Model Action
     * @return Value
     */
	function getcount_borangasetlupus(){
		$db = $this->GetModel();
		$sqltext = "SELECT COUNT(*) AS num FROM borang_aset_lupus";
		$queryparams = null;
		$val = $db->rawQueryValue($sqltext, $queryparams);
		
		if(is_array($val)){
			return $val[0];
		}
		return $val;
	}

}
