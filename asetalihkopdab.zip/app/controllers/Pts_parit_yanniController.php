<?php 
/**
 * Pts_parit_yanni Page Controller
 * @category  Controller
 */
class Pts_parit_yanniController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "pts_parit_yanni";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("kod_tempat", 
			"kategori_aset", 
			"kod_kategori", 
			"kod_sub_kategori", 
			"jenama", 
			"no_siri_aset");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				pts_parit_yanni.kod_tempat LIKE ? OR 
				pts_parit_yanni.ruang_simpanan LIKE ? OR 
				pts_parit_yanni.kategori_aset LIKE ? OR 
				pts_parit_yanni.kod_kategori LIKE ? OR 
				pts_parit_yanni.kod_sub_kategori LIKE ? OR 
				pts_parit_yanni.jenama LIKE ? OR 
				pts_parit_yanni.no_siri_aset LIKE ? OR 
				pts_parit_yanni.no_siri_pembuat LIKE ? OR 
				pts_parit_yanni.tempoh_jaminan LIKE ? OR 
				pts_parit_yanni.tarikh_terima LIKE ? OR 
				pts_parit_yanni.harga_perolehan_asal LIKE ? OR 
				pts_parit_yanni.no_pesanan LIKE ? OR 
				pts_parit_yanni.tarikh_pesanan LIKE ? OR 
				pts_parit_yanni.nama_pembekal LIKE ? OR 
				pts_parit_yanni.alamat LIKE ? OR 
				pts_parit_yanni.no_baucer LIKE ? OR 
				pts_parit_yanni.tarikh_cek LIKE ? OR 
				pts_parit_yanni.no_akaun_bank LIKE ? OR 
				pts_parit_yanni.no_check LIKE ? OR 
				pts_parit_yanni.disediakan_oleh LIKE ? OR 
				pts_parit_yanni.pengesahan_pengurus_besar LIKE ? OR 
				pts_parit_yanni.lokasi_penempatan LIKE ? OR 
				pts_parit_yanni.tarikh_penempatan LIKE ? OR 
				pts_parit_yanni.dibeli_oleh LIKE ? OR 
				pts_parit_yanni.lokasi_pindahan_semasa LIKE ? OR 
				pts_parit_yanni.tarikh_pindahan_semasa LIKE ? OR 
				pts_parit_yanni.tarikh_pemeriksaan LIKE ? OR 
				pts_parit_yanni.status_inventori LIKE ? OR 
				pts_parit_yanni.diperiksa_oleh LIKE ? OR 
				pts_parit_yanni.tarikh_lupus LIKE ? OR 
				pts_parit_yanni.maklumat_pelupusan LIKE ? OR 
				pts_parit_yanni.rekod_pergerakan_aset LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "pts_parit_yanni/search.php";
		}
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("pts_parit_yanni.kod_tempat", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = "Pts Parit Yanni";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		$this->render_view("pts_parit_yanni/list.php", $data); //render the full page
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("kod_tempat", 
			"kategori_aset", 
			"kod_kategori", 
			"kod_sub_kategori", 
			"jenama", 
			"no_siri_aset", 
			"no_siri_pembuat", 
			"tempoh_jaminan", 
			"tarikh_terima", 
			"harga_perolehan_asal", 
			"no_pesanan", 
			"tarikh_pesanan", 
			"nama_pembekal", 
			"alamat", 
			"no_baucer", 
			"tarikh_cek", 
			"no_akaun_bank", 
			"no_check", 
			"disediakan_oleh", 
			"pengesahan_pengurus_besar", 
			"lokasi_penempatan", 
			"tarikh_penempatan", 
			"dibeli_oleh", 
			"lokasi_pindahan_semasa", 
			"tarikh_pindahan_semasa", 
			"tarikh_pemeriksaan", 
			"status_inventori", 
			"diperiksa_oleh", 
			"tarikh_lupus", 
			"maklumat_pelupusan", 
			"rekod_pergerakan_aset");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("pts_parit_yanni.kod_tempat", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = "View  Pts Parit Yanni";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("pts_parit_yanni/view.php", $record);
	}
	/**
     * Insert new record to the database table
	 * @param $formdata array() from $_POST
     * @return BaseView
     */
	function add($formdata = null){
		if($formdata){
			$db = $this->GetModel();
			$tablename = $this->tablename;
			$request = $this->request;
			//fillable fields
			$fields = $this->fields = array("kod_tempat","kategori_aset","kod_kategori","kod_sub_kategori","jenama","no_siri_aset","no_siri_pembuat","tempoh_jaminan","tarikh_terima","harga_perolehan_asal","no_pesanan","tarikh_pesanan","nama_pembekal","alamat","no_baucer","tarikh_cek","no_akaun_bank","no_check","disediakan_oleh","pengesahan_pengurus_besar","lokasi_penempatan","tarikh_penempatan","dibeli_oleh","lokasi_pindahan_semasa","tarikh_pindahan_semasa","tarikh_pemeriksaan","status_inventori","diperiksa_oleh","tarikh_lupus","maklumat_pelupusan","rekod_pergerakan_aset");
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'kod_tempat' => 'required',
				'kategori_aset' => 'required',
				'kod_kategori' => 'required',
				'kod_sub_kategori' => 'required',
				'no_siri_aset' => 'required',
				'tarikh_terima' => 'required',
				'harga_perolehan_asal' => 'required',
				'disediakan_oleh' => 'required',
				'pengesahan_pengurus_besar' => 'required',
				'lokasi_penempatan' => 'required',
				'tarikh_penempatan' => 'required',
				'dibeli_oleh' => 'required',
				'status_inventori' => 'required',
				'maklumat_pelupusan' => 'required',
			);
			$this->sanitize_array = array(
				'kod_tempat' => 'sanitize_string',
				'kategori_aset' => 'sanitize_string',
				'kod_kategori' => 'sanitize_string',
				'kod_sub_kategori' => 'sanitize_string',
				'jenama' => 'sanitize_string',
				'no_siri_aset' => 'sanitize_string',
				'no_siri_pembuat' => 'sanitize_string',
				'tempoh_jaminan' => 'sanitize_string',
				'tarikh_terima' => 'sanitize_string',
				'harga_perolehan_asal' => 'sanitize_string',
				'no_pesanan' => 'sanitize_string',
				'tarikh_pesanan' => 'sanitize_string',
				'nama_pembekal' => 'sanitize_string',
				'alamat' => 'sanitize_string',
				'no_baucer' => 'sanitize_string',
				'tarikh_cek' => 'sanitize_string',
				'no_akaun_bank' => 'sanitize_string',
				'no_check' => 'sanitize_string',
				'disediakan_oleh' => 'sanitize_string',
				'pengesahan_pengurus_besar' => 'sanitize_string',
				'lokasi_penempatan' => 'sanitize_string',
				'tarikh_penempatan' => 'sanitize_string',
				'dibeli_oleh' => 'sanitize_string',
				'lokasi_pindahan_semasa' => 'sanitize_string',
				'tarikh_pindahan_semasa' => 'sanitize_string',
				'tarikh_pemeriksaan' => 'sanitize_string',
				'status_inventori' => 'sanitize_string',
				'diperiksa_oleh' => 'sanitize_string',
				'tarikh_lupus' => 'sanitize_string',
				'maklumat_pelupusan' => 'sanitize_string',
				'rekod_pergerakan_aset' => 'sanitize_string',
			);
			$this->filter_vals = true; //set whether to remove empty fields
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$rec_id = $this->rec_id = $db->insert($tablename, $modeldata);
				if($rec_id){
					$this->set_flash_msg("Record added successfully", "success");
					return	$this->redirect("pts_parit_yanni");
				}
				else{
					$this->set_page_error();
				}
			}
		}
		$page_title = $this->view->page_title = "Add New Pts Parit Yanni";
		$this->render_view("pts_parit_yanni/add.php");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function edit($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("kod_tempat","kategori_aset","kod_kategori","kod_sub_kategori","jenama","no_siri_aset","no_siri_pembuat","tempoh_jaminan","tarikh_terima","harga_perolehan_asal","no_pesanan","tarikh_pesanan","nama_pembekal","alamat","no_baucer","tarikh_cek","no_akaun_bank","no_check","disediakan_oleh","pengesahan_pengurus_besar","lokasi_penempatan","tarikh_penempatan","dibeli_oleh","lokasi_pindahan_semasa","tarikh_pindahan_semasa","tarikh_pemeriksaan","status_inventori","diperiksa_oleh","tarikh_lupus","maklumat_pelupusan","rekod_pergerakan_aset");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'kod_tempat' => 'required',
				'kategori_aset' => 'required',
				'kod_kategori' => 'required',
				'kod_sub_kategori' => 'required',
				'no_siri_aset' => 'required',
				'tarikh_terima' => 'required',
				'harga_perolehan_asal' => 'required',
				'disediakan_oleh' => 'required',
				'pengesahan_pengurus_besar' => 'required',
				'lokasi_penempatan' => 'required',
				'tarikh_penempatan' => 'required',
				'dibeli_oleh' => 'required',
				'status_inventori' => 'required',
				'maklumat_pelupusan' => 'required',
			);
			$this->sanitize_array = array(
				'kod_tempat' => 'sanitize_string',
				'kategori_aset' => 'sanitize_string',
				'kod_kategori' => 'sanitize_string',
				'kod_sub_kategori' => 'sanitize_string',
				'jenama' => 'sanitize_string',
				'no_siri_aset' => 'sanitize_string',
				'no_siri_pembuat' => 'sanitize_string',
				'tempoh_jaminan' => 'sanitize_string',
				'tarikh_terima' => 'sanitize_string',
				'harga_perolehan_asal' => 'sanitize_string',
				'no_pesanan' => 'sanitize_string',
				'tarikh_pesanan' => 'sanitize_string',
				'nama_pembekal' => 'sanitize_string',
				'alamat' => 'sanitize_string',
				'no_baucer' => 'sanitize_string',
				'tarikh_cek' => 'sanitize_string',
				'no_akaun_bank' => 'sanitize_string',
				'no_check' => 'sanitize_string',
				'disediakan_oleh' => 'sanitize_string',
				'pengesahan_pengurus_besar' => 'sanitize_string',
				'lokasi_penempatan' => 'sanitize_string',
				'tarikh_penempatan' => 'sanitize_string',
				'dibeli_oleh' => 'sanitize_string',
				'lokasi_pindahan_semasa' => 'sanitize_string',
				'tarikh_pindahan_semasa' => 'sanitize_string',
				'tarikh_pemeriksaan' => 'sanitize_string',
				'status_inventori' => 'sanitize_string',
				'diperiksa_oleh' => 'sanitize_string',
				'tarikh_lupus' => 'sanitize_string',
				'maklumat_pelupusan' => 'sanitize_string',
				'rekod_pergerakan_aset' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("pts_parit_yanni.kod_tempat", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("pts_parit_yanni");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("pts_parit_yanni");
					}
				}
			}
		}
		$db->where("pts_parit_yanni.kod_tempat", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Pts Parit Yanni";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("pts_parit_yanni/edit.php", $data);
	}
	/**
     * Update single field
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function editfield($rec_id = null, $formdata = null){
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		//editable fields
		$fields = $this->fields = array("kod_tempat","kategori_aset","kod_kategori","kod_sub_kategori","jenama","no_siri_aset","no_siri_pembuat","tempoh_jaminan","tarikh_terima","harga_perolehan_asal","no_pesanan","tarikh_pesanan","nama_pembekal","alamat","no_baucer","tarikh_cek","no_akaun_bank","no_check","disediakan_oleh","pengesahan_pengurus_besar","lokasi_penempatan","tarikh_penempatan","dibeli_oleh","lokasi_pindahan_semasa","tarikh_pindahan_semasa","tarikh_pemeriksaan","status_inventori","diperiksa_oleh","tarikh_lupus","maklumat_pelupusan","rekod_pergerakan_aset");
		$page_error = null;
		if($formdata){
			$postdata = array();
			$fieldname = $formdata['name'];
			$fieldvalue = $formdata['value'];
			$postdata[$fieldname] = $fieldvalue;
			$postdata = $this->format_request_data($postdata);
			$this->rules_array = array(
				'kod_tempat' => 'required',
				'kategori_aset' => 'required',
				'kod_kategori' => 'required',
				'kod_sub_kategori' => 'required',
				'no_siri_aset' => 'required',
				'tarikh_terima' => 'required',
				'harga_perolehan_asal' => 'required',
				'disediakan_oleh' => 'required',
				'pengesahan_pengurus_besar' => 'required',
				'lokasi_penempatan' => 'required',
				'tarikh_penempatan' => 'required',
				'dibeli_oleh' => 'required',
				'status_inventori' => 'required',
				'maklumat_pelupusan' => 'required',
			);
			$this->sanitize_array = array(
				'kod_tempat' => 'sanitize_string',
				'kategori_aset' => 'sanitize_string',
				'kod_kategori' => 'sanitize_string',
				'kod_sub_kategori' => 'sanitize_string',
				'jenama' => 'sanitize_string',
				'no_siri_aset' => 'sanitize_string',
				'no_siri_pembuat' => 'sanitize_string',
				'tempoh_jaminan' => 'sanitize_string',
				'tarikh_terima' => 'sanitize_string',
				'harga_perolehan_asal' => 'sanitize_string',
				'no_pesanan' => 'sanitize_string',
				'tarikh_pesanan' => 'sanitize_string',
				'nama_pembekal' => 'sanitize_string',
				'alamat' => 'sanitize_string',
				'no_baucer' => 'sanitize_string',
				'tarikh_cek' => 'sanitize_string',
				'no_akaun_bank' => 'sanitize_string',
				'no_check' => 'sanitize_string',
				'disediakan_oleh' => 'sanitize_string',
				'pengesahan_pengurus_besar' => 'sanitize_string',
				'lokasi_penempatan' => 'sanitize_string',
				'tarikh_penempatan' => 'sanitize_string',
				'dibeli_oleh' => 'sanitize_string',
				'lokasi_pindahan_semasa' => 'sanitize_string',
				'tarikh_pindahan_semasa' => 'sanitize_string',
				'tarikh_pemeriksaan' => 'sanitize_string',
				'status_inventori' => 'sanitize_string',
				'diperiksa_oleh' => 'sanitize_string',
				'tarikh_lupus' => 'sanitize_string',
				'maklumat_pelupusan' => 'sanitize_string',
				'rekod_pergerakan_aset' => 'sanitize_string',
			);
			$this->filter_rules = true; //filter validation rules by excluding fields not in the formdata
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			if($this->validated()){
				$db->where("pts_parit_yanni.kod_tempat", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount();
				if($bool && $numRows){
					return render_json(
						array(
							'num_rows' =>$numRows,
							'rec_id' =>$rec_id,
						)
					);
				}
				else{
					if($db->getLastError()){
						$page_error = $db->getLastError();
					}
					elseif(!$numRows){
						$page_error = "No record updated";
					}
					render_error($page_error);
				}
			}
			else{
				render_error($this->view->page_error);
			}
		}
		return null;
	}
	/**
     * Delete record from the database
	 * Support multi delete by separating record id by comma.
     * @return BaseView
     */
	function delete($rec_id = null){
		Csrf::cross_check();
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$this->rec_id = $rec_id;
		//form multiple delete, split record id separated by comma into array
		$arr_rec_id = array_map('trim', explode(",", $rec_id));
		$db->where("pts_parit_yanni.kod_tempat", $arr_rec_id, "in");
		$bool = $db->delete($tablename);
		if($bool){
			$this->set_flash_msg("Record deleted successfully", "success");
		}
		elseif($db->getLastError()){
			$page_error = $db->getLastError();
			$this->set_flash_msg($page_error, "danger");
		}
		return	$this->redirect("pts_parit_yanni");
	}
}
