<div class="container">
	<h4>HUBUNGI KAMI</h4>
	<hr />
	<div>
		CAWANGAN KOPDAB
	</div>
	<div>
		PTS Parit Yaani : HP 010-844 0113
	</div>
	<div>
		PTS Parit Raja : HP 010-844 0115
	</div>
	<div>
		PTS PT Yaani : HP 010-844 0113
	</div>
	<div>
		PTS Sri Dayong : HP 010-307 0075
	</div>
	<div>
		PTS Semerah : HP 010-844 0191

	</div>
	<div>
		PTS Rengit : HP 011-566 8974 0
	</div>
	<div>
		PTS Warijo : HP 010-843 1332
	</div>
	<div>
		Tapak Semaian : HP 010-343 8089
	</div>
	<div>
		Kedai Baja : HP 011-205 0299 1
	</div>
	<?php 
		if(DEVELOPMENT_MODE){ 
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/contact.php</i></small>
	<?php 
		} 
	?>
	
</div>