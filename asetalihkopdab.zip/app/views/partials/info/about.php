<div class="container">
	<h4>About</h4>
	<hr />
	<div>
		<p>Sistem Aset Alih KOPDAB berfungsi untuk memudahkan pengurusan rekod dan pergerakan aset di setiap pusat timbang. Sistem ini memudahkan pihak pengurusan untuk mengemaskini data dan rekod berkaitan aset untuk tujuan pengauditan. Setiap maklumat dapat dikemaskini melalui setiap pusat timbang secara atas talian dengan lebih efisien.</p>
		<?php 
			if(DEVELOPMENT_MODE){ 
		?>
			<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/about.php</i></small>
		<?php 
			} 
		?>
	</div>
</div>