<div class="container">
	<div class="jumbotron text-center">
		<h3>Get in touch! We're here for you...</h3>

            </div>

						<div class="col-sm-7">
				<div class="panel panel-body">
					<h4>Other Ways To Reach Us:</h4>
					<hr />

					<p>
						<b class="chead"><span class="material-icons">Alamat Kami|</span>waze| Lokasi</b><br />
						<p class="adr clearfix">
							<span class="adr-group">
								<span class="street-address">KOPERASI PEKEBUN KECIL DAERAH BATU PAHAT JOHOR</span><br>
								<span class="postal-code">No 30B, JALAN MENGKUDU, TAMAN DATO ABD RAHMAN JAAFAR</span><br>
								<span class="country-name">BATU PAHAT, JOHOR</span>
							</span>
						</p>
					</p>
					<hr />
					<p>
						<b class="chead"><span class="material-icons"></span>Phone Number</b><br />
						<span class="editContent"> +074377901/ +010-341 0709</span>
					</p>
					<hr />

					<p>
						<b class="chead"><span class="material-icons"></span> Email</b><br />
						<a href="#" class="editContent">kopdab@gmail.com</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<?php
	if (DEVELOPMENT_MODE) {
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/contact.php</i></small>
	<?php
	}
	?>

</div>