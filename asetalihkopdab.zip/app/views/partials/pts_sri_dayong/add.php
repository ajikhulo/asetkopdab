<?php
$comp_model = new SharedController;
$page_element_id = "add-page-" . random_str();
$current_page = $this->set_current_page_link();
$csrf_token = Csrf::$token;
$show_header = $this->show_header;
$view_title = $this->view_title;
$redirect_to = $this->redirect_to;
?>
<section class="page" id="<?php echo $page_element_id; ?>" data-page-type="add"  data-display-type="" data-page-url="<?php print_link($current_page); ?>">
    <?php
    if( $show_header == true ){
    ?>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col ">
                    <h4 class="record-title">Add New Pts Sri Dayong</h4>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <div  class="">
        <div class="container">
            <div class="row ">
                <div class="col-md-7 comp-grid">
                    <?php $this :: display_page_errors(); ?>
                    <div  class="bg-light p-3 animated fadeIn page-content">
                        <form id="pts_sri_dayong-add-form" role="form" novalidate enctype="multipart/form-data" class="form page-form form-horizontal needs-validation" action="<?php print_link("pts_sri_dayong/add?csrf_token=$csrf_token") ?>" method="post">
                            <div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="kod_tempat">Kod Tempat <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <select required=""  id="ctrl-kod_tempat" name="kod_tempat"  placeholder="Select a value ..."    class="custom-select" >
                                                    <option value="">Select a value ...</option>
                                                    <?php 
                                                    $kod_tempat_options = $comp_model -> pts_sri_dayong_kod_tempat_option_list();
                                                    if(!empty($kod_tempat_options)){
                                                    foreach($kod_tempat_options as $option){
                                                    $value = (!empty($option['value']) ? $option['value'] : null);
                                                    $label = (!empty($option['label']) ? $option['label'] : $value);
                                                    $selected = $this->set_field_selected('kod_tempat',$value, "");
                                                    ?>
                                                    <option <?php echo $selected; ?> value="<?php echo $value; ?>">
                                                        <?php echo $label; ?>
                                                    </option>
                                                    <?php
                                                    }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group ">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <label class="control-label" for="kategori_aset">Kategori Aset <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="">
                                                <input id="ctrl-kategori_aset"  value="<?php  echo $this->set_field_value('kategori_aset',""); ?>" type="text" placeholder="Enter Kategori Aset" list="kategori_aset_list"  required="" name="kategori_aset"  class="form-control " />
                                                    <datalist id="kategori_aset_list">
                                                        <?php 
                                                        $kategori_aset_options = $comp_model -> pts_sri_dayong_kategori_aset_option_list();
                                                        if(!empty($kategori_aset_options)){
                                                        foreach($kategori_aset_options as $option){
                                                        $value = (!empty($option['value']) ? $option['value'] : null);
                                                        $label = (!empty($option['label']) ? $option['label'] : $value);
                                                        ?>
                                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                        <?php
                                                        }
                                                        }
                                                        ?>
                                                    </datalist>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group ">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label class="control-label" for="kod_kategori">Kod Kategori <span class="text-danger">*</span></label>
                                            </div>
                                            <div class="col-sm-8">
                                                <div class="">
                                                    <input id="ctrl-kod_kategori"  value="<?php  echo $this->set_field_value('kod_kategori',""); ?>" type="text" placeholder="Enter Kod Kategori" list="kod_kategori_list"  required="" name="kod_kategori"  class="form-control " />
                                                        <datalist id="kod_kategori_list">
                                                            <?php 
                                                            $kod_kategori_options = $comp_model -> pts_sri_dayong_kod_kategori_option_list();
                                                            if(!empty($kod_kategori_options)){
                                                            foreach($kod_kategori_options as $option){
                                                            $value = (!empty($option['value']) ? $option['value'] : null);
                                                            $label = (!empty($option['label']) ? $option['label'] : $value);
                                                            ?>
                                                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                            <?php
                                                            }
                                                            }
                                                            ?>
                                                        </datalist>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label class="control-label" for="kod_sub_kategori">Kod Sub Kategori <span class="text-danger">*</span></label>
                                                </div>
                                                <div class="col-sm-8">
                                                    <div class="">
                                                        <input id="ctrl-kod_sub_kategori"  value="<?php  echo $this->set_field_value('kod_sub_kategori',""); ?>" type="text" placeholder="Enter Kod Sub Kategori" list="kod_sub_kategori_list"  required="" name="kod_sub_kategori"  class="form-control " />
                                                            <datalist id="kod_sub_kategori_list">
                                                                <?php 
                                                                $kod_sub_kategori_options = $comp_model -> pts_sri_dayong_kod_sub_kategori_option_list();
                                                                if(!empty($kod_sub_kategori_options)){
                                                                foreach($kod_sub_kategori_options as $option){
                                                                $value = (!empty($option['value']) ? $option['value'] : null);
                                                                $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                ?>
                                                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                                <?php
                                                                }
                                                                }
                                                                ?>
                                                            </datalist>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group ">
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <label class="control-label" for="kuantiti">Kuantiti </label>
                                                    </div>
                                                    <div class="col-sm-8">
                                                        <div class="">
                                                            <input id="ctrl-kuantiti"  value="<?php  echo $this->set_field_value('kuantiti',""); ?>" type="text" placeholder="Enter Kuantiti"  name="kuantiti"  class="form-control " />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group ">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label class="control-label" for="jenama">Jenama </label>
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="">
                                                                <input id="ctrl-jenama"  value="<?php  echo $this->set_field_value('jenama',""); ?>" type="text" placeholder="Enter Jenama" list="jenama_list"  name="jenama"  class="form-control " />
                                                                    <datalist id="jenama_list">
                                                                        <?php 
                                                                        $jenama_options = $comp_model -> pts_sri_dayong_jenama_option_list();
                                                                        if(!empty($jenama_options)){
                                                                        foreach($jenama_options as $option){
                                                                        $value = (!empty($option['value']) ? $option['value'] : null);
                                                                        $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                        ?>
                                                                        <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                                        <?php
                                                                        }
                                                                        }
                                                                        ?>
                                                                    </datalist>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="no_siri_aset">No Siri Aset <span class="text-danger">*</span></label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <textarea placeholder="Enter No Siri Aset" id="ctrl-no_siri_aset"  required="" rows="5" name="no_siri_aset" class=" form-control"><?php  echo $this->set_field_value('no_siri_aset',""); ?></textarea>
                                                                    <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group ">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label class="control-label" for="no_siri_pembuat">No Siri Pembuat </label>
                                                            </div>
                                                            <div class="col-sm-8">
                                                                <div class="">
                                                                    <input id="ctrl-no_siri_pembuat"  value="<?php  echo $this->set_field_value('no_siri_pembuat',""); ?>" type="text" placeholder="Enter No Siri Pembuat"  name="no_siri_pembuat"  class="form-control " />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group ">
                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <label class="control-label" for="tempoh_jaminan">Tempoh Jaminan </label>
                                                                </div>
                                                                <div class="col-sm-8">
                                                                    <div class="">
                                                                        <input id="ctrl-tempoh_jaminan"  value="<?php  echo $this->set_field_value('tempoh_jaminan',""); ?>" type="text" placeholder="Enter Tempoh Jaminan"  name="tempoh_jaminan"  class="form-control " />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group ">
                                                                <div class="row">
                                                                    <div class="col-sm-4">
                                                                        <label class="control-label" for="tarikh_terima">Tarikh Terima <span class="text-danger">*</span></label>
                                                                    </div>
                                                                    <div class="col-sm-8">
                                                                        <div class="">
                                                                            <input id="ctrl-tarikh_terima"  value="<?php  echo $this->set_field_value('tarikh_terima',""); ?>" type="text" placeholder="Enter Tarikh Terima"  required="" name="tarikh_terima"  class="form-control " />
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group ">
                                                                    <div class="row">
                                                                        <div class="col-sm-4">
                                                                            <label class="control-label" for="harga_perolehan_asal">Harga Perolehan Asal <span class="text-danger">*</span></label>
                                                                        </div>
                                                                        <div class="col-sm-8">
                                                                            <div class="">
                                                                                <input id="ctrl-harga_perolehan_asal"  value="<?php  echo $this->set_field_value('harga_perolehan_asal',""); ?>" type="text" placeholder="Enter Harga Perolehan Asal"  required="" name="harga_perolehan_asal"  class="form-control " />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group ">
                                                                        <div class="row">
                                                                            <div class="col-sm-4">
                                                                                <label class="control-label" for="no_pesanan">No Pesanan </label>
                                                                            </div>
                                                                            <div class="col-sm-8">
                                                                                <div class="">
                                                                                    <input id="ctrl-no_pesanan"  value="<?php  echo $this->set_field_value('no_pesanan',""); ?>" type="text" placeholder="Enter No Pesanan"  name="no_pesanan"  class="form-control " />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group ">
                                                                            <div class="row">
                                                                                <div class="col-sm-4">
                                                                                    <label class="control-label" for="tarikh_pesanan">Tarikh Pesanan <span class="text-danger">*</span></label>
                                                                                </div>
                                                                                <div class="col-sm-8">
                                                                                    <div class="">
                                                                                        <input id="ctrl-tarikh_pesanan"  value="<?php  echo $this->set_field_value('tarikh_pesanan',""); ?>" type="text" placeholder="Enter Tarikh Pesanan"  required="" name="tarikh_pesanan"  class="form-control " />
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group ">
                                                                                <div class="row">
                                                                                    <div class="col-sm-4">
                                                                                        <label class="control-label" for="nama_pembekal">Nama Pembekal </label>
                                                                                    </div>
                                                                                    <div class="col-sm-8">
                                                                                        <div class="">
                                                                                            <input id="ctrl-nama_pembekal"  value="<?php  echo $this->set_field_value('nama_pembekal',""); ?>" type="text" placeholder="Enter Nama Pembekal"  name="nama_pembekal"  class="form-control " />
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group ">
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label class="control-label" for="alamat">Alamat </label>
                                                                                        </div>
                                                                                        <div class="col-sm-8">
                                                                                            <div class="">
                                                                                                <textarea placeholder="Enter Alamat" id="ctrl-alamat"  rows="5" name="alamat" class=" form-control"><?php  echo $this->set_field_value('alamat',""); ?></textarea>
                                                                                                <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group ">
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label class="control-label" for="no_baucer">No Baucer </label>
                                                                                        </div>
                                                                                        <div class="col-sm-8">
                                                                                            <div class="">
                                                                                                <input id="ctrl-no_baucer"  value="<?php  echo $this->set_field_value('no_baucer',""); ?>" type="text" placeholder="Enter No Baucer"  name="no_baucer"  class="form-control " />
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group ">
                                                                                        <div class="row">
                                                                                            <div class="col-sm-4">
                                                                                                <label class="control-label" for="tarikh_cek">Tarikh Cek </label>
                                                                                            </div>
                                                                                            <div class="col-sm-8">
                                                                                                <div class="">
                                                                                                    <input id="ctrl-tarikh_cek"  value="<?php  echo $this->set_field_value('tarikh_cek',""); ?>" type="text" placeholder="Enter Tarikh Cek"  name="tarikh_cek"  class="form-control " />
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group ">
                                                                                            <div class="row">
                                                                                                <div class="col-sm-4">
                                                                                                    <label class="control-label" for="no_akaun_bank">No Akaun Bank </label>
                                                                                                </div>
                                                                                                <div class="col-sm-8">
                                                                                                    <div class="">
                                                                                                        <input id="ctrl-no_akaun_bank"  value="<?php  echo $this->set_field_value('no_akaun_bank',""); ?>" type="text" placeholder="Enter No Akaun Bank"  name="no_akaun_bank"  class="form-control " />
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="form-group ">
                                                                                                <div class="row">
                                                                                                    <div class="col-sm-4">
                                                                                                        <label class="control-label" for="no_check">No Check </label>
                                                                                                    </div>
                                                                                                    <div class="col-sm-8">
                                                                                                        <div class="">
                                                                                                            <input id="ctrl-no_check"  value="<?php  echo $this->set_field_value('no_check',""); ?>" type="text" placeholder="Enter No Check"  name="no_check"  class="form-control " />
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="form-group ">
                                                                                                    <div class="row">
                                                                                                        <div class="col-sm-4">
                                                                                                            <label class="control-label" for="disediakan_oleh">Disediakan Oleh <span class="text-danger">*</span></label>
                                                                                                        </div>
                                                                                                        <div class="col-sm-8">
                                                                                                            <div class="">
                                                                                                                <input id="ctrl-disediakan_oleh"  value="<?php  echo $this->set_field_value('disediakan_oleh',""); ?>" type="text" placeholder="Enter Disediakan Oleh"  required="" name="disediakan_oleh"  class="form-control " />
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="form-group ">
                                                                                                        <div class="row">
                                                                                                            <div class="col-sm-4">
                                                                                                                <label class="control-label" for="pengesahan_pengurus_besar">Pengesahan Pengurus Besar <span class="text-danger">*</span></label>
                                                                                                            </div>
                                                                                                            <div class="col-sm-8">
                                                                                                                <div class="">
                                                                                                                    <input id="ctrl-pengesahan_pengurus_besar"  value="<?php  echo $this->set_field_value('pengesahan_pengurus_besar',""); ?>" type="text" placeholder="Enter Pengesahan Pengurus Besar"  required="" name="pengesahan_pengurus_besar"  class="form-control " />
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="form-group ">
                                                                                                            <div class="row">
                                                                                                                <div class="col-sm-4">
                                                                                                                    <label class="control-label" for="lokasi_penempatan">Lokasi Penempatan <span class="text-danger">*</span></label>
                                                                                                                </div>
                                                                                                                <div class="col-sm-8">
                                                                                                                    <div class="">
                                                                                                                        <input id="ctrl-lokasi_penempatan"  value="<?php  echo $this->set_field_value('lokasi_penempatan',""); ?>" type="text" placeholder="Enter Lokasi Penempatan"  required="" name="lokasi_penempatan"  class="form-control " />
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div class="form-group ">
                                                                                                                <div class="row">
                                                                                                                    <div class="col-sm-4">
                                                                                                                        <label class="control-label" for="tarikh_penempatan">Tarikh Penempatan <span class="text-danger">*</span></label>
                                                                                                                    </div>
                                                                                                                    <div class="col-sm-8">
                                                                                                                        <div class="">
                                                                                                                            <input id="ctrl-tarikh_penempatan"  value="<?php  echo $this->set_field_value('tarikh_penempatan',""); ?>" type="text" placeholder="Enter Tarikh Penempatan"  required="" name="tarikh_penempatan"  class="form-control " />
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div class="form-group ">
                                                                                                                    <div class="row">
                                                                                                                        <div class="col-sm-4">
                                                                                                                            <label class="control-label" for="dibeli_oleh">Dibeli Oleh <span class="text-danger">*</span></label>
                                                                                                                        </div>
                                                                                                                        <div class="col-sm-8">
                                                                                                                            <div class="">
                                                                                                                                <input id="ctrl-dibeli_oleh"  value="<?php  echo $this->set_field_value('dibeli_oleh',""); ?>" type="text" placeholder="Enter Dibeli Oleh"  required="" name="dibeli_oleh"  class="form-control " />
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                    <div class="form-group ">
                                                                                                                        <div class="row">
                                                                                                                            <div class="col-sm-4">
                                                                                                                                <label class="control-label" for="lokasi_pindahan_semasa">Lokasi Pindahan Semasa </label>
                                                                                                                            </div>
                                                                                                                            <div class="col-sm-8">
                                                                                                                                <div class="">
                                                                                                                                    <input id="ctrl-lokasi_pindahan_semasa"  value="<?php  echo $this->set_field_value('lokasi_pindahan_semasa',""); ?>" type="text" placeholder="Enter Lokasi Pindahan Semasa" list="lokasi_pindahan_semasa_list"  name="lokasi_pindahan_semasa"  class="form-control " />
                                                                                                                                        <datalist id="lokasi_pindahan_semasa_list">
                                                                                                                                            <?php 
                                                                                                                                            $lokasi_pindahan_semasa_options = $comp_model -> pts_sri_dayong_lokasi_pindahan_semasa_option_list();
                                                                                                                                            if(!empty($lokasi_pindahan_semasa_options)){
                                                                                                                                            foreach($lokasi_pindahan_semasa_options as $option){
                                                                                                                                            $value = (!empty($option['value']) ? $option['value'] : null);
                                                                                                                                            $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                                                                                            ?>
                                                                                                                                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                                                                                                                            <?php
                                                                                                                                            }
                                                                                                                                            }
                                                                                                                                            ?>
                                                                                                                                        </datalist>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        <div class="form-group ">
                                                                                                                            <div class="row">
                                                                                                                                <div class="col-sm-4">
                                                                                                                                    <label class="control-label" for="tarikh_pindahan_semasa">Tarikh Pindahan Semasa </label>
                                                                                                                                </div>
                                                                                                                                <div class="col-sm-8">
                                                                                                                                    <div class="">
                                                                                                                                        <input id="ctrl-tarikh_pindahan_semasa"  value="<?php  echo $this->set_field_value('tarikh_pindahan_semasa',""); ?>" type="text" placeholder="Enter Tarikh Pindahan Semasa"  name="tarikh_pindahan_semasa"  class="form-control " />
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                            <div class="form-group ">
                                                                                                                                <div class="row">
                                                                                                                                    <div class="col-sm-4">
                                                                                                                                        <label class="control-label" for="tarikh_pemeriksaan">Tarikh Pemeriksaan </label>
                                                                                                                                    </div>
                                                                                                                                    <div class="col-sm-8">
                                                                                                                                        <div class="">
                                                                                                                                            <input id="ctrl-tarikh_pemeriksaan"  value="<?php  echo $this->set_field_value('tarikh_pemeriksaan',""); ?>" type="text" placeholder="Enter Tarikh Pemeriksaan"  name="tarikh_pemeriksaan"  class="form-control " />
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div class="form-group ">
                                                                                                                                    <div class="row">
                                                                                                                                        <div class="col-sm-4">
                                                                                                                                            <label class="control-label" for="status_inventori">Status Inventori <span class="text-danger">*</span></label>
                                                                                                                                        </div>
                                                                                                                                        <div class="col-sm-8">
                                                                                                                                            <div class="">
                                                                                                                                                <select required=""  id="ctrl-status_inventori" name="status_inventori"  placeholder="Select a value ..."    class="custom-select" >
                                                                                                                                                    <option value="">Select a value ...</option>
                                                                                                                                                    <?php 
                                                                                                                                                    $status_inventori_options = $comp_model -> pts_sri_dayong_status_inventori_option_list();
                                                                                                                                                    if(!empty($status_inventori_options)){
                                                                                                                                                    foreach($status_inventori_options as $option){
                                                                                                                                                    $value = (!empty($option['value']) ? $option['value'] : null);
                                                                                                                                                    $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                                                                                                    $selected = $this->set_field_selected('status_inventori',$value, "");
                                                                                                                                                    ?>
                                                                                                                                                    <option <?php echo $selected; ?> value="<?php echo $value; ?>">
                                                                                                                                                        <?php echo $label; ?>
                                                                                                                                                    </option>
                                                                                                                                                    <?php
                                                                                                                                                    }
                                                                                                                                                    }
                                                                                                                                                    ?>
                                                                                                                                                </select>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div class="form-group ">
                                                                                                                                    <div class="row">
                                                                                                                                        <div class="col-sm-4">
                                                                                                                                            <label class="control-label" for="diperiksa_oleh">Diperiksa Oleh </label>
                                                                                                                                        </div>
                                                                                                                                        <div class="col-sm-8">
                                                                                                                                            <div class="">
                                                                                                                                                <input id="ctrl-diperiksa_oleh"  value="<?php  echo $this->set_field_value('diperiksa_oleh',""); ?>" type="text" placeholder="Enter Diperiksa Oleh"  name="diperiksa_oleh"  class="form-control " />
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="form-group ">
                                                                                                                                        <div class="row">
                                                                                                                                            <div class="col-sm-4">
                                                                                                                                                <label class="control-label" for="tarikh_lupus">Tarikh Lupus </label>
                                                                                                                                            </div>
                                                                                                                                            <div class="col-sm-8">
                                                                                                                                                <div class="">
                                                                                                                                                    <input id="ctrl-tarikh_lupus"  value="<?php  echo $this->set_field_value('tarikh_lupus',""); ?>" type="text" placeholder="Enter Tarikh Lupus"  name="tarikh_lupus"  class="form-control " />
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div class="form-group ">
                                                                                                                                            <div class="row">
                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                    <label class="control-label" for="maklumat_pelupusan">Maklumat Pelupusan </label>
                                                                                                                                                </div>
                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                    <div class="">
                                                                                                                                                        <select  id="ctrl-maklumat_pelupusan" name="maklumat_pelupusan"  placeholder="Select a value ..."    class="custom-select" >
                                                                                                                                                            <option value="">Select a value ...</option>
                                                                                                                                                            <?php 
                                                                                                                                                            $maklumat_pelupusan_options = $comp_model -> pts_sri_dayong_maklumat_pelupusan_option_list();
                                                                                                                                                            if(!empty($maklumat_pelupusan_options)){
                                                                                                                                                            foreach($maklumat_pelupusan_options as $option){
                                                                                                                                                            $value = (!empty($option['value']) ? $option['value'] : null);
                                                                                                                                                            $label = (!empty($option['label']) ? $option['label'] : $value);
                                                                                                                                                            $selected = $this->set_field_selected('maklumat_pelupusan',$value, "");
                                                                                                                                                            ?>
                                                                                                                                                            <option <?php echo $selected; ?> value="<?php echo $value; ?>">
                                                                                                                                                                <?php echo $label; ?>
                                                                                                                                                            </option>
                                                                                                                                                            <?php
                                                                                                                                                            }
                                                                                                                                                            }
                                                                                                                                                            ?>
                                                                                                                                                        </select>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div class="form-group ">
                                                                                                                                            <div class="row">
                                                                                                                                                <div class="col-sm-4">
                                                                                                                                                    <label class="control-label" for="rekod_pergerakan_aset">Rekod Pergerakan Aset </label>
                                                                                                                                                </div>
                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                    <div class="">
                                                                                                                                                        <textarea placeholder="Enter Rekod Pergerakan Aset" id="ctrl-rekod_pergerakan_aset"  rows="5" name="rekod_pergerakan_aset" class=" form-control"><?php  echo $this->set_field_value('rekod_pergerakan_aset',""); ?></textarea>
                                                                                                                                                        <!--<div class="invalid-feedback animated bounceIn text-center">Please enter text</div>-->
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="form-group form-submit-btn-holder text-center mt-3">
                                                                                                                                        <div class="form-ajax-status"></div>
                                                                                                                                        <button class="btn btn-primary" type="submit">
                                                                                                                                            Submit
                                                                                                                                            <i class="fa fa-send"></i>
                                                                                                                                        </button>
                                                                                                                                    </div>
                                                                                                                                </form>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </section>
